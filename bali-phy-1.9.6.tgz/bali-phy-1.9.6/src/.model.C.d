.model.C.d model.o: model.C model.H clone.H mytypes.H log-double.H logsum.H   le-double.H
