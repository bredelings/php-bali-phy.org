.sequencetree.C.d sequencetree.o: sequencetree.C sequencetree.H tree.H tree-branchnode.H   myexception.H util.H
