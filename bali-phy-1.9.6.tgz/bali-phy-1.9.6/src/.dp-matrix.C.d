.dp-matrix.C.d dp-matrix.o: dp-matrix.C dp-matrix.H dp-engine.H hmm.H mytypes.H   log-double.H logsum.H le-double.H refcount.H pow2.H choose.H rng.H   myexception.H
