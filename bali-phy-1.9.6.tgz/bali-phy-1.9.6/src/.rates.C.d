.rates.C.d rates.o: rates.C rates.H model.H clone.H mytypes.H log-double.H logsum.H   le-double.H probability.H rng.H util.H myexception.H
