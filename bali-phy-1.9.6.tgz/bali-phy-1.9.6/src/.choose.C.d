.choose.C.d choose.o: choose.C choose.H rng.H mytypes.H log-double.H logsum.H   le-double.H myexception.H
