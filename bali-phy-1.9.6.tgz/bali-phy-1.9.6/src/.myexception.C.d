.myexception.C.d myexception.o: myexception.C myexception.H
