.alignment-random.C.d alignment-random.o: alignment-random.C alignment.H alphabet.H   myexception.H clone.H sequence.H sequence-format.H mytypes.H   log-double.H logsum.H le-double.H rng.H
