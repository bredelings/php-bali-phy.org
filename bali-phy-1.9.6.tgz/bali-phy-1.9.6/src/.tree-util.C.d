.tree-util.C.d tree-util.o: tree-util.C tree-util.H sequencetree.H tree.H   tree-branchnode.H myexception.H
