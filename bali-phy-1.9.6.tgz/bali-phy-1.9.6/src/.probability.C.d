.probability.C.d probability.o: probability.C probability.H logsum.H
