.sequence-format.C.d sequence-format.o: sequence-format.C sequence-format.H sequence.H util.H   myexception.H
