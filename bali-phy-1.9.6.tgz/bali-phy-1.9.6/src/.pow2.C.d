.pow2.C.d pow2.o: pow2.C pow2.H
