#include <valarray>
#include <iostream>
#include <cmath>
#include <cassert>
#include "sample.H"
#include "logsum.H"
#include "choose.H"
#include "bits.H"
#include "util.H"
#include "rng.H"
#include "5way.H"
#include "alignment-sums.H"
#include "alignment-util.H"
#include "substitution-index.H"
#include <boost/numeric/ublas/io.hpp>
#include "refcount.H"
#include "dp-array.H"

// for prior(p[i])
#include "likelihood.H"

// We are sampling from a 5-way alignment (along 5 branches)

// Its a 4-way dynamic programming, though - so the only thing
// that matters is the order of the 4D path. (I think...)

// We want to scramble the sorting method for the branches
// Perhaps that should be the NEXT step?  We can scramble the
// node names, though - we use those to know which leaf node
// is connected to which internal node.

// Branches are labelled 0-3, as are the leaves.  Internal nodes
// are 4,5; internal branch is 5.

using std::abs;
using std::valarray;

using namespace A5;

// IDEA: make a routine which encapsulates this sampling, and passes back
//  the total_sum.  Then we can just call sample_two_nodes w/ each of the 3 trees.
// We can choose between them with the total_sum (I mean, sum_all_paths).
// Then, we can just debug one routine, basically.

RefPtr<DParrayConstrained> sample_two_nodes_base(alignment& A,const Parameters& P,const vector<int>& nodes) {

  const Tree& T = P.T;
  alignment old = A;

  //  std::cerr<<"old = "<<old<<endl;

  /*------------- Compute sequence properties --------------*/
  vector<int> columns = getorder(old,nodes);

  //  std::cerr<<"n0 = "<<n0<<"   n1 = "<<n1<<"    n2 = "<<n2<<"    n3 = "<<n3<<std::endl;
  //  std::cerr<<"old (reordered) = "<<project(old,nodes)<<endl;

  // Find sub-alignments and sequences
  vector<vector<int> > seqs(4);
  for(int i=0;i<seqs.size();i++)
    seqs[i].reserve(A.length());
  vector<int> seqall;
  seqall.reserve(A.length());
  for(int i=0;i<columns.size();i++) {
    int column = columns[i];
    for(int i=0;i<4;i++)
      if (not old.gap(column,nodes[i]))
	seqs[i].push_back(column);

    if (not old.gap(column,nodes[0]) or 
	not old.gap(column,nodes[1]) or 
	not old.gap(column,nodes[2]) or 
	not old.gap(column,nodes[3]))
      seqall.push_back(column);
  }

  // Map columns with n2 or n3 to single index 'c'
  //  vector< vector<int> > cols(4,vector<int>(seqall.size()+1));
  vector<int> icol(seqall.size()+1);
  vector<int> jcol(seqall.size()+1);
  vector<int> kcol(seqall.size()+1);
  vector<int> lcol(seqall.size()+1);

  icol[0] = 0;
  jcol[0] = 0;
  kcol[0] = 0;
  lcol[0] = 0;
  for(int c=1,i=0,j=0,k=0,l=0;c<seqall.size()+1;c++) {
    if (not old.gap(seqall[c-1],nodes[0]))
      i++;    
    if (not old.gap(seqall[c-1],nodes[1]))
      j++;    
    if (not old.gap(seqall[c-1],nodes[2]))
      k++;
    if (not old.gap(seqall[c-1],nodes[3]))
      l++;
    icol[c] = i;
    jcol[c] = j;
    kcol[c] = k;
    lcol[c] = l;
  }


  /*-------------- Create alignment matrices ---------------*/

  // Construct the 1D state-emit matrix from the 6D one
  vector<int> state_emit_1D = A5::states_list;
  for(int S2=0;S2<state_emit_1D.size();S2++) {
    int state_emit = state_emit_1D[S2]&leafbitsmask;
    if (state_emit)
      state_emit_1D[S2] = 1;
    else
      state_emit_1D[S2] = 0;
  }
  
  // Create the transition matrix first using just the current, fixed ordering
  vector<int> branches(5);
  branches[0] = T.branch(nodes[0],nodes[4]);
  branches[1] = T.branch(nodes[1],nodes[4]);
  branches[2] = T.branch(nodes[2],nodes[5]);
  branches[3] = T.branch(nodes[3],nodes[5]);
  branches[4] = T.branch(nodes[4],nodes[5]);
  const Matrix Q = createQ(P.branch_HMMs,branches,A5::states_list);
  vector<double> start_P = get_start_P(P.branch_HMMs,branches);

  // Actually create the Matrices & Chain
  RefPtr<DParrayConstrained> Matrices = new DParrayConstrained(seqall.size(), 
							       state_emit_1D, 
							       start_P,
							       Q, 
							       P.Temp);

  // Determine which states are allowed to match (c2)
  for(int c2=0;c2<Matrices->size();c2++) {
    int i2 = icol[c2];
    int j2 = jcol[c2];
    int k2 = kcol[c2];
    int l2 = lcol[c2];
    Matrices->states(c2).reserve(Matrices->nstates());
    for(int i=0;i<Matrices->nstates();i++) {
      int S2 = Matrices->order(i);
      int state2 = A5::states_list[S2];

      //---------- Get (,j1,k1) ----------
      int i1 = i2;
      if (bitset(state2,0)) i1--;

      int j1 = j2;
      if (bitset(state2,1)) j1--;

      int k1 = k2;
      if (bitset(state2,2)) k1--;

      int l1 = l2;
      if (bitset(state2,3)) l1--;
      
      //------ Get c1, check if valid ------
      if (c2==0 
	  or (i1 == i2 and j1 == j2 and k1 == k2 and l1 == l2) 
	  or (i1 == icol[c2-1] and j1 == jcol[c2-1] and k1 == kcol[c2-1] and l1 == lcol[c2-1]) )
	Matrices->states(c2).push_back(S2);
      else
	; // this state not allowed here
    }
  }

  /*------------------ Compute the DP matrix ---------------------*/

  //  Matrices.prune(); broken!
  Matrices->forward();

  //------------- Sample a path from the matrix -------------------//

  vector<int> path_g = Matrices->sample_path();
  vector<int> path = Matrices->ungeneralize(path_g);

  //  std::cerr<<"generalized A = \n"<<construct(old,path_g,nodes,T,seqs,A5::states_list)<<endl;
  //  std::cerr<<"ungeneralized A = \n"<<construct(old,path,nodes,T,seqs,A5::states_list)<<endl;

  A = construct(old,path,nodes,T,seqs,A5::states_list);

  //  std::cerr<<"A = \n"<<construct(old,path,nodes,T,seqs,A5::states_list)<<endl;

#ifndef NDEBUG_DP
  vector<int> newnodes;
  for(int i=0;i<6;i++)
    newnodes.push_back(i);

  vector<int> path_new = get_path(project(A,nodes),newnodes,A5::states_list);
  vector<int> path_new2 = get_path(A,nodes,A5::states_list);
  assert(path_new == path_new2); // <- current implementation probably guarantees this
                                 //    but its not a NECESSARY effect of the routine.

  // get the generalized paths - no sequential silent states that can loop
  vector<int> path_new_g = Matrices->generalize(path_new);
  assert(path_new_g == path_g);
  assert(path_new   == path);
  assert(valid(A));
#endif

  return Matrices;
}

///(a[0],p[0]) is the point from which the proposal originates, and must be valid.
int sample_two_nodes_multi(vector<alignment>& a,vector<Parameters>& p,const vector< vector<int> >& nodes_,
			   const vector<efloat_t>& rho_,bool do_OS,bool do_OP) 
{

  vector<vector<int> > nodes = nodes_;
  vector<efloat_t> rho = rho_;
  assert(p.size() == nodes.size());
  
  //----------- Generate the different states and Matrices ---------//
  const alignment A0 = a[0];
#ifndef NDEBUG_DP
  const Parameters P0 = p[0];
#endif

  vector< RefPtr<DParrayConstrained> > Matrices;
  for(int i=0;i<p.size();i++) {
    Matrices.push_back( sample_two_nodes_base(a[i],p[i],nodes[i]) );
    //    p[i].LC.invalidate_node(p[i].T,nodes[i][4]);
    //    p[i].LC.invalidate_node(p[i].T,nodes[i][5]);
#ifndef NDEBUG
    if (i==0) substitution::check_subA(A0,a[0],p[0].T);
    p[i].likelihood(a[i],p[i]);  // check the likelihood calculation
#endif
  }

  //-------- Calculate corrections to path probabilities ---------//

  vector<efloat_t> OS(p.size(),1);
  vector<efloat_t> OP(p.size(),1);
  for(int i=0; i<p.size(); i++) {
    if (do_OS) 
      OS[i] = p[i].likelihood(a[i],p[i]);
    if (do_OP)
      OP[i] = other_prior(a[i],p[i],nodes[i]);
  }

  //---------------- Calculate choice probabilities --------------//
  vector<efloat_t> Pr(p.size());
  for(int i=0;i<Pr.size();i++)
    Pr[i] = rho[i] * OS[i] * Matrices[i]->Pr_sum_all_paths() * OP[i] * pow(prior(p[i]),1.0/p[i].Temp);

  int C = choose_MH(0,Pr);

#ifndef NDEBUG_DP
  std::cerr<<"choice = "<<C<<endl;

  // One mask for all p[i] assumes that only ignored nodes can be renamed
  valarray<bool> ignore(false,p[0].T.n_nodes());
  ignore[ nodes[0][4] ] = true;
  ignore[ nodes[0][5] ] = true;

  // Check that our constraints are met
  for(int i=0;i<a.size();i++) {
    if (not (A_constant(A0,a[i],ignore))) {
      std::cerr<<A0<<endl;
      std::cerr<<a[i]<<endl;
      assert(A_constant(A0,a[i],ignore));
    }
  }

  // Add another entry for the incoming configuration
  a.push_back( A0 );
  p.push_back( P0 );
  nodes.push_back(nodes[0]);
  rho.push_back( rho[0] );
  Matrices.push_back( Matrices[0] );
  OS.push_back( OS[0] );
  OP.push_back( OP[0] );

  vector< vector<int> > paths;

  vector<int> newnodes;
  for(int i=0;i<6;i++)
    newnodes.push_back(i);

  //------------------- Check offsets from path_Q -> P -----------------//
  for(int i=0;i<p.size();i++) {
    paths.push_back( get_path(A5::project(a[i],nodes[i]),newnodes,A5::states_list) );
    
    OS[i] = p[i].likelihood(a[i],p[i]);
    OP[i] = other_prior(a[i],p[i],nodes[i]);

    efloat_t OP_i = OP[i] / A5::correction(a[i],p[i],nodes[i]);

    check_match_P(a[i], p[i], OS[i], OP_i, paths[i], *Matrices[i]);
  }

  //--------- Compute path probabilities and sampling probabilities ---------//
  vector< vector<efloat_t> > PR(p.size());

  for(int i=0;i<p.size();i++) {
    efloat_t proposal_ratio = 1;
    if (i<Pr.size())
      proposal_ratio = choose_MH_P(0,i,Pr)/choose_MH_P(i,0,Pr);
    else
      proposal_ratio = 1;

    PR[i] = sample_P(a[i], p[i], proposal_ratio, rho[i], paths[i], *Matrices[i]);
    PR[i][0] *= A5::correction(a[i],p[i],nodes[i]);
  }

  //--------- Check that each choice is sampled w/ the correct Probability ---------//
  check_sampling_probabilities(PR,a);
#endif

  //---------------- Adjust for length of n4 and n5 changing --------------------//

  // if we reject the move, then don't do anything
  if (myrandomf() > A5::acceptance_ratio(A0,p[0],nodes[0],a[C],p[C],nodes[C])) 
    return -1;

  return C;
}


void sample_two_nodes(alignment& A, Parameters& P,int b) 
{
  vector<alignment> a(1,A);
  vector<Parameters> p(1,P);

  vector< vector<int> > nodes(1);
  nodes[0] = A5::get_nodes_random(P.T,b);

  vector<efloat_t> rho(1,1);

  int C = sample_two_nodes_multi(a,p,nodes,rho,false,false);

  if (C != -1) {
    A = a[C];
    P = p[C];
  }
}
