A text version of the full HTML readme file is included below.

However, we recommend using the HTML version (doc/README.html).  The
HTML version is much clearer because it can use bold and italic fonts
to indicate, for example, that the text "filename" should be replaced
by an actual filename.



----------------------------------------------------------------------
Document's Title: BAli-Phy User's Guide

BAli-Phy User's Guide

    Benjamin Redelings

    --------------------------------------------------------------

    Table of Contents

    Running the Program
    Command Line Arguments
         Usage
         General options
         MCMC options
         Parameter options
         Substitution model options
         Alignment Constraints

    Examples
    Output
         Output Streams
         Output Files
         Processing the Output
         Results

    Models
         Substitution Models
         Indel Models

    Auxilliary Tools
         tree-dist-compare


  Running the Program

    The simplest way to run bali-phy is to invoke the bali-phy executable
    directly:

     % ./bali-phy sequence-file >out 2>err

    Here sequence-file is a FASTA or PHYLIP file containing the sequences you
    wish to analyze.

    The recommended way to run the program is to copy the bali-phy executable
    to ~/bin/bali-phy/version-NDEBUG and run (in a bourne-shell)

     % VERSION=version CLASS=class sampler.sh sequence-file



    The wrapper script sampler.sh will run bali-phy for you. It will also
    create a unique directory for each invocation of the program, and put
    output files in this directory. The directories will be named class-1,
    class-2, etc.

    Note

    In many cases it is necessary to specify the location of the data
    directory in order to run the program. The data directory defaults to
    ./Data if not explicitly set. (See option --data-dir).

  Command Line Arguments

    Usage

    The syntax for the program is:

    bali-phy {sequence-file} [OPTIONS]

    The sequence file is the only required argument. It can be either a FASTA
    (*.fasta) file or a PHYLIP (*.phy) file. The file must end in one of
    these two suffixes or bali-phy won't know how to read it. In addition
    your FASTA files should not contain any blank lines.

    The optional arguments are described below.

    General options

       --help

       produce help messasge

       --version

       print version information

       --show-only

       analyze the initial values and exit

       --data-dir directory

       data directory

       --align-constraint constraint-file

       specify file with alignment constraints

       --with-stop

       include stop codons in amino-acid alphabets

       --internal arg

       include stop codons in amino-acid alphabets

       --with-stop

       if set to '+', then make all internal node entries wildcards

       --gaps arg

       if set to 'star', then don't use indel information

       --letters arg

       if set to 'star', then use a star tree for substitution

    MCMC options

       --iterations number=10000

       the number of iterations to run

       --subsample factor=1

       factor by which to subsample

       --T temperature=1

       MCMCMCMC temperature

       --enable move

       comma-separated list of kernels to enable

       --disable move

       comma-separated list of kernels to disnable

    Parameter options

       --tree treefile

       file with initial tree

       --set parameter=value

       specify initial parameter value.

       --fix parameter[=value]

       specify initial parameter value, and optionally mark parameter fixed.

       --unfix parameter[=value]

       specify initial parameter value, and optionally mark parameter fixed.

       --randomize-alignment

       randomly re-align sequences before use.

       --smodel substitution-model

       specify the substitution model

       --imodel indel-model

       specify the indel model

    Substitution model options

       --frequencies frequencies

       initial frequencies: 'uniform','nucleotides', or a comma-separated
       list of frequencies.

       --alphabet alphabet

       specify the alphabet: DNA, RNA, Amino Acids, Triplets, or Codons.

    Alignment Constraints

    To pin columns of the alignment, specify alignment constraints in a file
    as follows:

       1. Use the argument --align-constraint filename
       2. The filename refers to a file in which each line represents a
          constraint.

    The first line of the file is a header consisting of an ordered list of
    sequence names separated by spaces. Each subsequent line consists of a
    space-separated list of sequence positions, with the first position
    corresponding to the first leaf sequence, the second position
    corresponding to the second leaf sequence, etc. Thus, if there are <n>
    leaf taxa, then each line corresponds to a space-separated list of <n>
    integers.

    For example, the line

    1 2 2

    means that position 1 of leaf sequence 1 is aligned to position 2 of leaf
    sequences 2 and 3. Note that the first position in a sequence is position
    0.

    Optionally, one may use a '-' instead of an integer, which denotes a lack
    of constraint for that sequence. This can be useful as follows:

    2 2 - - 
    - - 2 2

    The above constraints force alignment between position 2 of sequences 1
    and 2, and between position 2 of sequence 3 and 4.

  Examples

    Here are some examples which demonstrate how to run bali-phy:



    Example 1. No frills

    Here we analyze the EF-Tu 5-taxon data set provided with the software.
    The alignment is randomized before the chain begins.

     % bali-phy Data/EF-Tu/5d.fasta --randomize_alignment >out 2>err



    Example 2. Multiple-Rate Substitution Model

    We now modify the previous example by changing the substitution model to
    allow gamma-distributed rate variation and invariant sites. The amount of
    rate variation and the fraction of invariant sites are estimated

     % bali-phy Data/EF-Tu/5d.fasta --smodel gamma+INV --randomize-alignment >out 2>err



    Example 3. Fixed alignment

    Here we use the 5S rRNA 5-taxon data set provided with the software. The
    alignment is fixed and the traditional likelihood model is used, making
    indels non-informative. In addition, the transition kernel which samples
    nucleotide frequencies is disabled, fixing the nucleotide frequencies to
    empirical values estimated from the input sequences.

     % bali-phy Data/5S-rRNA/5d.fasta ---disable frequencies --gaps star >out 2>err

  Output

    Output Streams

    bali-phy writes out the sampled alignments and other information to the
    standard output stream, which displays on the terminal by default. Error
    messages are written to the standard error stream, which also displays on
    the terminal by default. In addition some other useful information is
    written to the standard error stream, such as the acceptance fraction for
    the various transition kernels.

    You should redirect the standard output to a file called out and redirect
    the standard error to a file called err so that the information on these
    streams is available for later analysis. In addition, some scripts assume
    that the names out and err are used. The way to redirect these streams to
    the files is to specify >out 2>err on the command line.

    Output Files

    When run in a clean directory, bali-phy produces the following output
    files. Beside the file MAP that contains alignments, each line in these
    files should correspond to one iteration.

       Pr

       prior, likelihood, probability

       pI

       indel model parameters

       pS

       substitution model parameters

       trees

       tree samples

       MAP

       successive estimates of the MAP point

    Processing the Output

    Copy (or link, using ln -s) the file bin/GNUmakefile into the current
    directory. Then run the command:

     % SKIP=burn-in make

    or

     % SKIP=burn-in SIZE=iterations make

    Here, burn-in represents the number of iterations to skip as burn-in, and
    iterations represents the maximum number of iterations to use in the
    analysis. In order for this to work, you must have having built the tools
    in the tools/ directory and have placed them in your path.

    Results

    The procedure mentioned above should produce the following files:

       Report

       A summary of results

       analysis

       A summary of the data analyzed

       tc

       Detailed description of posterior support for trees and partitions

       MAP.fasta

       An estimate of the MAP alignment, w/ taxa sorted by similarity

       MAP.tree

       An estimate of the MAP tree, in Newick format

       tree.srq

       A bit-vector of the time-series of the support of the MAP.tree

       tree.plot

       A summed version of tree.srq. Type plot 'tree.plot' in gnuplot.

    In addition, if you type SKIP=burn-in make blame.html, the following
    files will be produced:

       blame.html

       An AU plot

       blame.prob

       The probabilities for each letter in the AU plot

  Models

    Substitution Models

    All of BAli-Phy's substitution models are mixtures of continuous-time
    Markov chains (CTMC). These mixtures can consist of the same CTMC model
    run at a mixture of rates (e.g. a gamma rate model) or parameters (e.g. a
    Yang M2 model), or even mixture of different models.

      Default Substitution Models

    If the substitution model is not specified, then the default model for
    the alphabet is used. For DNA or RNA, the default model is HKY. For
    Codons, the default model is YangM0. For AminoAcids, the default model is
    Empirical[WAG].

      Specifying a Substitution Model

    Substitution models are specified using a stack, as follows:
    Model[arg]+Model[arg]+...+Model[arg] where each model uses the previous
    models as input. Arguments are optional.

    The basic CTMC models are EQU, HKY, TN, Empirical, and YangM0.

    Model modifiers are gamma, INV, and YangM2.

      Examples

    Example: --smodel EQU --alphabet Triplets.

    Example: --smodel Empirical[WAG]+gamma+INV.

    Example: --smodel YangM0+YangM2 --alphabet Codons..

    Example: --smodel YangM0+YangM2 --alphabet Codons.

      Extended Model Descriptions

    All basic CTMC models are reversible, and can be characterized by Q[i][j]
    = S[i][j]*pi[j]^f/pi[i]^(1-f), where pi[ ] are the equilibrium
    frequencies for the Markov chain.

       EQU

       S[i][j] = 1 for every i and j. Preconditions: the alphabet must be DNA
       or RNA. Parameters: none.

       HKY

       The Hasegawa, Kishina, Yano 1985 model. Preconditions: the alphabet
       must be DNA or RNA. Parameters: kappa, the transition/transversion
       ratio.

       TN

       The Tamura, Nei 1993 model. Preconditions: the alphabet must be DNA or
       RNA. Parameters: kappa1, the transition/transversion ratio for
       purines. kappa2, the transition/transition ratio for pyrimadines.

       YangM0

       The ?? model. Preconditions: the alphabet must be Codons. Parameters:
       kappa, the transition/transversion ratio. omega, the
       non-synonymous/synonymous substitution ratio.

       One can also specify YangM0[submodel]. In this case, YangM0[HKY] gives
       the standard Yang M0 model, whereas YangM0[TN] give two
       transition/transversion rates.

    Indel Models

    The current models are simple,fragments, and fragments+T

  Auxilliary Tools

    tree-dist-compare

    Usage:



--------------------------------------------------------------
List of References

Document's URL:  /home/bredelin/Devel/Sampler/trunk/doc/README.html
docbook.css

