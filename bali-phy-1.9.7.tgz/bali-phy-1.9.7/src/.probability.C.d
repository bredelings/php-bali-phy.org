.probability.C.d probability.o: probability.C probability.H log-double.H logsum.H
