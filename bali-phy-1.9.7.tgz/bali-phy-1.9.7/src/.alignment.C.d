.alignment.C.d alignment.o: alignment.C alignment.H alphabet.H myexception.H clone.H   sequence.H sequence-format.H mytypes.H log-double.H logsum.H util.H   rng.H
