#include <vector>
#include <iostream>

using namespace std;

int main() {
  vector<int> a(4);
  for(int i=0;i<a.size();i++)
    a[i] = i;

  vector<vector<int> > v(1,a);
  v.push_back(v[0]);
  v.push_back(a);
  v.push_back(v[0]);
  v.push_back(v[0]);
  v.push_back(a);

  for(int i=0;i<v.size()+2;i++)
    cout<<"v["<<i<<"].size() = "<<v[i].size()<<endl;
}
  
  
