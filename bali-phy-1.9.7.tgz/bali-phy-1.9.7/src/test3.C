#include <vector>
#include <iostream>
#include "smodel.H"
#include "clone.H"

struct A {
  virtual void f() {std::cout<<"A\n";}
};

struct B: public A {
  virtual void f() {std::cout<<"B\n";}
};

struct C: virtual public A {
  virtual void f() {std::cout<<"C\n";}
};

using namespace std;
using namespace substitution;

int main() {
  DNA dna;
  AminoAcids aa;

  vector<OwnedPointer<substitution::Model> > stack;
  stack.push_back(UnitModel(HKY(dna)));

  substitution::Model* gen_model1 = new UnitModel(HKY(dna));
  substitution::Model* gen_model2 = new UnitModel(Empirical(aa,"Data/wag.dat"));

  substitution::MultiModel* mmodel1 = dynamic_cast<substitution::MultiModel*>(gen_model1);
  substitution::MultiModel* mmodel2 = dynamic_cast<substitution::MultiModel*>(gen_model2);

  if (mmodel1)
    std::cout<<"conversion1 worked.\n";
  else
    std::cout<<"conversion1 failed.\n";

  if (mmodel2)
    std::cout<<"conversion2 worked.\n";
  else
    std::cout<<"conversion2 failed.\n";

  A a;
  B b;
  C c;

  a.f();
  b.f();
  c.f();

  vector<A*> av;
  av.push_back(&a);
  av.push_back(&b);
  av.push_back(&c);

  std::cout<<"--------------\n";
  for(int i=0;i<av.size();i++) {
    B* bp = dynamic_cast<B*>(av[i]);
    if (bp)
      bp->f();
  }

  std::cout<<"--------------\n";
  for(int i=0;i<av.size();i++) {
    C* cp = dynamic_cast<C*>(av[i]);
    if (cp)
      cp->f();
  }


}
  
  
