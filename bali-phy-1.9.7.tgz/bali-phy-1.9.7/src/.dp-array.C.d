.dp-array.C.d dp-array.o: dp-array.C dp-array.H dp-engine.H hmm.H mytypes.H   log-double.H logsum.H refcount.H pow2.H choose.H rng.H myexception.H
