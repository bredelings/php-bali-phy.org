#include <vector>
#include <iostream>
#include "setup.H"
#include "rng.H"


int main(int argc,char* argv[]) { 

  try {
    Arguments args;
    args.read(argc,argv);

    //---------- Initialize random seed -----------//
    unsigned long seed = 0;
    if (args.set("seed")) {
      seed = convertTo<unsigned long>(args["seed"]);
      myrand_init(seed);
    }
    else
      seed = myrand_init();
    std::cout<<"random seed = "<<seed<<endl<<endl;
    
    alignment A;
    SequenceTree T;
    args["random_tree_ok"] = "yes";
    load_A_and_T(args,A,T);
    std::cout<<"alphabet = "<<A.get_alphabet().name<<endl<<endl;
    OwnedPointer<substitution::MultiModel> smodel = get_smodel(args,A);

    std::cout<<"subst model = "<<smodel->name();
  }
  catch (std::exception& e) {
    std::cerr<<"Error: "<<e.what()<<endl;
    exit(1);
  }

  return 0;
}
  
  
