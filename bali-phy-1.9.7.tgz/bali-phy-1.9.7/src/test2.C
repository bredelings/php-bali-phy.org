#include <vector>
#include <iostream>

struct A {
  virtual void f() {std::cout<<"A\n";}
};

struct B: public A {
  virtual void f() {std::cout<<"B\n";}
};

struct C: virtual public A {
  virtual void f() {std::cout<<"C\n";}
};

using namespace std;

int main() {
  A a;
  B b;
  C c;

  a.f();
  b.f();
  c.f();

  vector<A*> av;
  av.push_back(&a);
  av.push_back(&b);
  av.push_back(&c);

  std::cout<<"--------------\n";
  for(int i=0;i<av.size();i++) {
    B* bp = dynamic_cast<B*>(av[i]);
    if (bp)
      bp->f();
  }

  std::cout<<"--------------\n";
  for(int i=0;i<av.size();i++) {
    C* cp = dynamic_cast<C*>(av[i]);
    if (cp)
      cp->f();
  }


}
  
  
