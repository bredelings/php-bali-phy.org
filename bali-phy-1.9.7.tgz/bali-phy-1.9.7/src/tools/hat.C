#include <iostream>
#include <vector>
#include <fstream>
#include "util.H"
#include "util-random.H"
#include "rng.H"

using namespace std;

vector<string> get_names(const string& filename) 
{
  vector<string> names;

  ifstream file(filename.c_str());

  if (not file)
    std::cout<<"could not open file "<<filename<<std::endl;

  // each line is a person's name
  string line;
  while(getline(file,line))
    names.push_back(line);

  return names;
}

vector<int> segment(int L) {
  vector<int> segs(1,L);

  // get initial segments
  while(segs[0] > 3) {
    segs.push_back(2);
    segs[0] -= 2;
  }

  // convert 3*2 -> 2*3
  // later

  return segs;
}

int main(int argc,char* argv[]) 
{
  myrand_init();


  // complain if we have the wrong number of arguments
  if (argc != 2)
    std::abort();

  // read the names from the filename we got
  vector<string> names = get_names(argv[1]);

  // randomize the names order
  vector<string> names2 = randomize(names);

  // get the list of segment sizes
  vector<int> blocks = segment(names2.size());

  // for each segment size
  while(not blocks.empty()) {

    // take that many names
    for(int j=0;j<blocks.back();j++) {
      std::cout<<names2.back()<<" ";
      names2.pop_back();
    }
    std::cout<<"\n";

    // we are don't with this block
    blocks.pop_back();
  }
}
