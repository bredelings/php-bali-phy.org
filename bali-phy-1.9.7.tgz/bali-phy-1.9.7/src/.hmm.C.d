.hmm.C.d hmm.o: hmm.C hmm.H mytypes.H log-double.H logsum.H choose.H rng.H   myexception.H
