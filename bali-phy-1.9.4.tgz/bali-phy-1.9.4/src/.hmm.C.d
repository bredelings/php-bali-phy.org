.hmm.C.d hmm.o: hmm.C hmm.H mytypes.H log-double.H logsum.H le-double.H choose.H
