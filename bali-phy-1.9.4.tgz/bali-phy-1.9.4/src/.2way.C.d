.2way.C.d 2way.o: 2way.C 2way.H alignment.H alphabet.H myexception.H clone.H   sequence.H mytypes.H log-double.H logsum.H le-double.H   sequence-format.H tree.H tree-branchnode.H alignment-util.H
