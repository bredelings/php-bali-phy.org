.sequence-format.C.d sequence-format.o: sequence-format.C sequence-format.H sequence.H   mytypes.H log-double.H logsum.H le-double.H alphabet.H myexception.H   clone.H util.H
