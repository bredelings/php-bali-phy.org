.dp-engine.C.d dp-engine.o: dp-engine.C dp-engine.H hmm.H mytypes.H log-double.H   logsum.H le-double.H choose.H rng.H
