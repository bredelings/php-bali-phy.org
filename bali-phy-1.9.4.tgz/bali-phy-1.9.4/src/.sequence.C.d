.sequence.C.d sequence.o: sequence.C sequence.H mytypes.H log-double.H logsum.H   le-double.H alphabet.H myexception.H clone.H util.H
