.choose.C.d choose.o: choose.C choose.H log-double.H logsum.H le-double.H rng.H   myexception.H
